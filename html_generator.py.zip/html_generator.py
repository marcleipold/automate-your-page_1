def generate_notes_HTML(notes_heading, notes_content):
	html_text_1 = '''
<div class="notes">
	<div class="notes-heading">
		''' + notes_heading

	html_text_2 = '''
	</div>
	<div class="notes-content">
	''' + notes_content
	html_text_3 = '''
	</div>
</div>'''

	full_html_text = html_text_1 + html_text_2 + html_text_3
	return full_html_text

def get_heading(notes):
	start_location = notes.find('HEADING:')
	end_location = notes.find('CONTENT:')
	heading = notes[start_location+9 : end_location-1]
	return heading
		
def get_content(notes):
	start_location = notes.find('CONTENT')
	content = notes[start_location+9 :]
	return content

def get_notes_by_number(text, notes_number):
	counter = 0 
	while counter < notes_number:
		counter = counter + 1
		next_notes_start = text.find('HEADING')
		next_notes_end = text.find('HEADING', next_notes_start + 1)
		notes = text[next_notes_start:next_notes_end]
		text = text[next_notes_end:]
	return notes 

# Data list
TEST_TEXT = """
HEADING: What is Programming?
CONTENT: A web crawler finds web pages for the search engine by starting a seed page
 and following links on that page to other pages, each of those, link to new web 
 pages which can have new links to other pages.  As we follow the links we'll 
 find more and more web pages building a collection of data that we'll use for 
 our search engine.  A link is a special type of text in that web page.

HEADING: Computer
CONTENT: a machine that can execute a program- with the right program, a computer 
can do any mechanical computation you can imagine

HEADING: Program
CONTENT: a very precise sequence of steps- since the computer is just a machine, 
the program must give the steps in a way that can be executed mechanically- that is, 
the program can be followed without any thought

HEADING: Programming
CONTENT: a language designed for producing computer programs- a good programming 
language makes it easy for humans to read and write programs that can be executed 
by a computer

HEADING: Python
CONTENT: a programming language- the programs that we write in the Python language 
will be the input to the Python interpreter, which is a program that runs on the 
computer- the Python interpreter reads our programs and executes them by following 
the rules of the Python language

HEADING: Getting Started with Python
CONTENT: 2 parts to screen: editor & output window. We can see the value of something 
in Python by using the print statement."""

def generate_all_html(text):
	current_notes_number = 1
	notes = get_notes_by_number(text, current_notes_number)
	all_html = ''
	while notes != '':
		heading = get_heading(notes)
		content = get_content(notes)
		notes_html = generate_notes_HTML(heading, content)
		all_html = all_html + notes_html
		current_notes_number = current_notes_number + 1
		notes = get_notes_by_number(text, current_notes_number)
	return all_html

print generate_all_html(TEST_TEXT)










